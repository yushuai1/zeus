package main

import (
	"net"
	"fmt"
	"encoding/binary"
	"irisking.com/algorithm-iris/algo_test/tcp/taskadd"
	"github.com/gogo/protobuf/proto"
	"irisking.com/algorithm-iris/params"
	"irisking.com/algorithm-iris"
	"time"
)

//单独处理客户端的请求
func clientHandle(conn net.Conn) {

	for {
		data := make([]byte, 4);
		//从conn中读取数据
		_, err := conn.Read(data);
		if err != nil {
			break
		}
		lens := int(binary.BigEndian.Uint32(data))
		//发送给客户端的数据
		datastring := make([]byte, lens);
		_, err = conn.Read(datastring)
		if err != nil {
			break
		}
		unObj := &pro_add.TaskData{}
		proto.Unmarshal(datastring, unObj)

		taskadd := unObj.FeatureList

		for _, v := range taskadd {
			verifyParams33 := params.IrisVerifyParamsStruct{v.IrisEnrTemplate, v.GetIrisRecTemplate()}
			ret1, matchScore := algo.IrisVerify(&verifyParams33)
			fmt.Println(ret1, matchScore)
		}

		///反向发回去
		unObj.PersonId = "返回"
		fanhui,_:=proto.Marshal(unObj)
		var buf = make([]byte, 4)
		binary.BigEndian.PutUint32(buf, uint32(len(fanhui)))
		conn.Write(buf);
		conn.Write(fanhui)

	}
}

func main() {
	tcpaddr, err := net.ResolveTCPAddr("tcp4", "127.0.0.1:8084");
	if err != nil {
		fmt.Println(err, "------")
	}

	tcplisten, err := net.ListenTCP("tcp", tcpaddr);
	if err != nil {
		fmt.Println(err, "------")
	}
	go func() {
		for {
			conn, err3 := tcplisten.Accept();
			if err3 != nil {
				continue;
			} else {
				fmt.Println("客户端连接成功！", conn.RemoteAddr())
			}

			go clientHandle(conn);
		}
	}()

	for true {
		time.Sleep(time.Millisecond * 5000 * 12)
	}
}
